# Torneo de Ajedrez (Frontend Firebase)

Sitio público + Panel Admin (Round Robin + Publicación de Pareos).

## Archivos
- `index.html` — Página pública (ranking y pareos de la ronda actual).
- `admin.html` — Generador de calendario **Round Robin** y botón **Publicar ronda actual**.
- `app.js` — Lógica de la página pública (ESM v9).
- `style.css` — Modo oscuro premium + estilos de tarjetas y admin.
- `firebase-config.js` — **Exporta** `firebaseConfig` (rellenar con tus credenciales).

## Requisitos
- Firebase Realtime Database habilitado.
- Reglas (recomendadas en prod):
```json
{
  "rules": {
    "players":   { ".read": true, ".write": "auth != null" },
    "pairings":  { ".read": true, ".write": "auth != null" },
    "tournament":{ ".read": true, ".write": "auth != null" },
    "calendario":{ ".read": true, ".write": "auth != null" }
  }
}
```

## Flujo
1. Sube todos los archivos a GitHub Pages.
2. Edita `firebase-config.js` con tus credenciales.
3. Carga jugadores en `/jugadores` con `{ nombre, elo, whatsapp }` (o `telefono`).  
4. En `admin.html`:
   - Elige "ELO descendente".
   - **Generar calendario** → **Guardar en /calendario**.
   - **Publicar ronda actual** (usa `tournament.currentRound`).
5. En `index.html` verás:
   - **Ranking 3/1/0** con badges Top-3.
   - Pareos de la **ronda actual** con botones de **WhatsApp**.

¡Buen torneo! ♟️
